<div class="plugin_description">
	This plugin removes unreferenced attributes from products after product import.
</div>