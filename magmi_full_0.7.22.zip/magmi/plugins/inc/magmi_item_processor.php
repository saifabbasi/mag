<?php

require_once("magmi_generalimport_plugin.php");

abstract class Magmi_ItemProcessor extends Magmi_GeneralImportPlugin
{
    /* No methods here to optimize processing

   You can define any of the import workflow hooks here */
}
