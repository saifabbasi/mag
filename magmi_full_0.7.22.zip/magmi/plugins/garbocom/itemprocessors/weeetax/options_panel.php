<ul class="formline">
	<li class="label">Weee Tax Attribute name</li>
	<li class="value"><input type="text" name="WEEE:attributes"
		value="<?php echo $this->getParam("WEEE:attributes", "ecotaxe")?>"></input></li>
</ul>
<ul class="formline">
	<li class="label">Weee Tax Country code</li>
	<li class="value"><input type="text" name="WEEE:country"
		value="<?php echo $this->getParam("WEEE:country", "FR")?>"></input></li>
</ul>
